package com.dam.model.db;

public class UsuarioContract {
	

	
	public static final String COL_NOMBRE = "NOMBRE";
	public static final String COL_CONTRASEÑA = "CONTRASEÑA";
	public static final String NOM_TABLA = "USUARIO";
}
