package com.dam.model.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.dam.model.data.Usuario;
;



public class ProgralingoPersistencia {
	
	private AccesoDB acceso;
	
	public ProgralingoPersistencia() {
		acceso = new AccesoDB();
	}
	
	public int registrarUsuario(Usuario usuario) {
		// res = 1 --> registrar restaurante correctamente
		//res = 0 --> si el restaurante ya existe
		int res = 0;
		
		String query = "INSERT INTO " + UsuarioContract.NOM_TABLA + " ("
				+ UsuarioContract.COL_NOMBRE + ", " + UsuarioContract.COL_CONTRASEÑA +") VALUES (?, ?)";
				
		Connection con = null;
		PreparedStatement pstmt = null;
				
		try {
			con = acceso.getConexion();
			
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, usuario.getNombre());
			pstmt.setString(2, usuario.getContraseña());
			
					
			res = pstmt.executeUpdate();
					
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			res = -1;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
				
		return res;
	}

	
	
}
