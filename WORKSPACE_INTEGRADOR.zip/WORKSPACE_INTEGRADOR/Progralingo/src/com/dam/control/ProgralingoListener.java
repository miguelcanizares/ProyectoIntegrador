package com.dam.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import com.dam.model.data.Usuario;
import com.dam.model.db.ProgralingoPersistencia;
import com.dam.view.IntroLeng;
import com.dam.view.Login;
import com.dam.view.ModificarUsuario;
import com.dam.view.PConsultarUsuarios;
import com.dam.view.PPrincipal;
import com.dam.view.PanelOpciones;
import com.dam.view.Registro;
import com.dam.view.TestPanelC;
import com.dam.view.TestPanelCplus;
import com.dam.view.TestPanelJ;
import com.dam.view.TestPanelP;



public class ProgralingoListener implements ActionListener {
	
	
	
	private Login lg ;
	private ModificarUsuario mu;
	private PanelOpciones po ;
	private PConsultarUsuarios pcu;
	private IntroLeng il ;
	private TestPanelC tpc ;
	private TestPanelCplus tpcp ;
	private TestPanelJ tpj ;
	private TestPanelP tpp ;
	private PPrincipal pp;
	private Registro rg;
	private ProgralingoPersistencia datosRestaurantes;
	
	

	public ProgralingoListener(PPrincipal pp) {
		this.pp = pp;
		datosRestaurantes = new ProgralingoPersistencia();
	}

	
	public void setLogin(Login lg) {
		this.lg = lg;
		
	}
	public void setRegistro(Registro rg) {
		this.rg = rg;
	}


	public void setMu(ModificarUsuario mu) {
		this.mu = mu;
		
	}

	public void setPo(PanelOpciones po) {
		this.po = po;
		
	}

	public void setPcu(PConsultarUsuarios pcu) {
		this.pcu = pcu;
	}

	public void setIl(IntroLeng il) {
		this.il = il;
		
	}

	public void setTpc(TestPanelC tpc) {
		this.tpc = tpc;
		
	}

	public void setTpcp(TestPanelCplus tpcp) {
		this.tpcp = tpcp;
		
	}

	public void setTpj(TestPanelJ tpj) {
		this.tpj = tpj;
	}

	public void setTpp(TestPanelP tpp) {
		this.tpp = tpp;
		
	}
	
	@Override
	public void actionPerformed(ActionEvent ev) {
		if (ev.getSource() instanceof JMenuItem) {
			if (ev.getSource().equals(pp.getMntmRegistro())) {
				
				pp.cargarPanel(rg);
				
			} else if (ev.getSource().equals(pp.getMntmInicioSesion())) {
				pp.cargarPanel(lg);
				
			}
		} else {
			if (ev.getSource().equals(rg.getBtnOK())) {
				
			    if (registrarUsuario()) {
                    pp.cargarPanel(po);
                }
			}else if (ev.getSource().equals(lg.getBtnLogin())) {
				pp.cargarPanel(po);
				
			} else if(ev.getSource().equals(po.getBtnCerrarSesion())) {
				
			}else if(ev.getSource().equals(po.getBtnLenguajes())) {
				pp.cargarPanel(il);
			}else if(ev.getSource().equals(il.getBtnCplus())) {
				pp.cargarPanel(po);
			}else if(ev.getSource().equals(il.getBtnCplus())) {
				pp.cargarPanel(po);
			}else if(ev.getSource().equals(il.getBtnCplus())) {
				pp.cargarPanel(po);
			}else if(ev.getSource().equals(il.getBtnCplus())) {
				pp.cargarPanel(po);
			}else if(ev.getSource().equals(po.getBtnModificar())) {
				pp.cargarPanel(mu);
			}
		
	}
	
}
	 public boolean registrarUsuario() {
	        Usuario usuario = rg.obtenerUsuario();

	        if (usuario != null) {
	            int res = datosRestaurantes.registrarUsuario(usuario);

	            if (res == 1) {
	                JOptionPane.showMessageDialog(rg, "Se ha registrado el restaurante con éxito",
	                        "Resultado de Operación", JOptionPane.INFORMATION_MESSAGE);
	                return true;
	            } else if (res == -1) {
	                JOptionPane.showMessageDialog(rg, "No se ha podido registrar",
	                        "Resultado de Operación", JOptionPane.ERROR_MESSAGE);
	            } else if (res == 0) {
	                JOptionPane.showMessageDialog(rg, "No se ha podido registrar",
	                        "Resultado de Operación", JOptionPane.ERROR_MESSAGE);
	            }
	        }
	        return false;
	    }
}



