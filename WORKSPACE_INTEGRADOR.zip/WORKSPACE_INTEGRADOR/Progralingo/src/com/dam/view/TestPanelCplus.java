package com.dam.view;
import java.awt.EventQueue;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.EmptyBorder;

import com.dam.control.ProgralingoListener;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TestPanelCplus extends JFrame {
    private JPanel contentPane;
    private JLabel lblPregunta;
    private JRadioButton[] optionButtons;
    private ButtonGroup group;
    private JButton btnNext, btnCorregir;
    private int currentQuestionIndex = 0;
    private int[] selectedAnswers;
    private int[] correctAnswers = {0, 0, 2, 2, 3, 1, 0, 0, 0, 2};

    
    private String[] questions = {
    	    "¿Qué palabra clave se utiliza para definir una función en Python?",
    	    "¿Qué símbolo se utiliza para comentar una línea en Python?",
    	    "¿Qué tipo de datos se utiliza para almacenar una cadena de caracteres en Python?",
    	    "¿Cuál de los siguientes es un tipo de dato mutable en Python?",
    	    "¿Cuál es la salida de la expresión '5' + '5' en Python?",
    	    "¿Cuál es el resultado de la operación 3//2 en Python?",
    	    "¿Cuál de las siguientes estructuras se utiliza para manejar excepciones en Python?",
    	    "¿Cómo se define una lista por comprensión en Python?",
    	    "¿Cuál es la diferencia principal entre una lista y un conjunto en Python?",
    	    "¿Cuál de las siguientes declaraciones es correcta para abrir un archivo en modo escritura en Python?"
    	};

    	private String[][] optionsText = {
    	    {"def", "function", "fun", "define"},
    	    {"#", "//", "/*", "%"},
    	    {"char", "string", "str", "text"},
    	    {"tuple", "str", "list", "int"},
    	    {"10", "55", "Error", "'55'"},
    	    {"1.5", "1", "2", "1.0"},
    	    {"try/except", "do/catch", "try/catch", "attempt/except"},
    	    {"[x for x in range(5)]", "list(x for x in range(5))", "{x for x in range(5)}", "list[x for x in range(5)]"},
    	    {"Una lista es ordenada y un conjunto no.", "Un conjunto es ordenado y una lista no.", "No hay diferencia.", "Una lista no permite duplicados y un conjunto sí."},
    	    {"file = open('archivo.txt', 'r')", "file = open('archivo.txt', 'rw')", "file = open('archivo.txt', 'w')", "file = open('archivo.txt', 'a')"}
    	};

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    TestPanelCplus frame = new TestPanelCplus();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public TestPanelCplus() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 350);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);

        lblPregunta = new JLabel();
        lblPregunta.setBounds(10, 11, 414, 50);
        contentPane.add(lblPregunta);

        optionButtons = new JRadioButton[4];
        group = new ButtonGroup();

        for (int i = 0; i < 4; i++) {
            optionButtons[i] = new JRadioButton();
            optionButtons[i].setBounds(10, 70 + (i * 25), 400, 23);
            contentPane.add(optionButtons[i]);
            group.add(optionButtons[i]);
        }
        btnNext = new JButton("Siguiente"); 
        btnNext.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveSelectedAnswer();
                
                
                boolean answered = false;
                for (int i = 0; i < selectedAnswers.length; i++) {
                    if (selectedAnswers[i] != -1) {
                        answered = true;
                        break;
                    }
                }
                
                if (!answered) {
                    JOptionPane.showMessageDialog(null, "Debes responder la pregunta para avanzar.");
                    return; 
                }
                
                if (currentQuestionIndex < questions.length - 1) {
                    currentQuestionIndex++;
                    updateQuestion();
                } else {
                    JOptionPane.showMessageDialog(null, "Has completado el quiz! Ahora puedes corregir tus respuestas.");
                    btnNext.setEnabled(false);
                    btnCorregir.setEnabled(true);
                }
            }
        });
        btnNext.setBounds(10, 270, 100, 23);
        contentPane.add(btnNext);

        btnCorregir = new JButton("Corregir");
        btnCorregir.setBounds(120, 270, 100, 23);
        btnCorregir.setEnabled(false);
        contentPane.add(btnCorregir);

        setContentPane(contentPane);

        selectedAnswers = new int[questions.length];
        for (int i = 0; i < selectedAnswers.length; i++) {
            selectedAnswers[i] = -1; 
        }

        updateQuestion();
    }

    private void updateQuestion() {
        lblPregunta.setText("<html>" + questions[currentQuestionIndex].replace("\n", "<br>") + "</html>");
        for (int i = 0; i < 4; i++) {
            optionButtons[i].setText(optionsText[currentQuestionIndex][i]);
            optionButtons[i].setSelected(false);
        }
        if (selectedAnswers[currentQuestionIndex] != -1) {
            optionButtons[selectedAnswers[currentQuestionIndex]].setSelected(true);
        }
    }

    private void saveSelectedAnswer() {
        for (int i = 0; i < 4; i++) {
            if (optionButtons[i].isSelected()) {
                selectedAnswers[currentQuestionIndex] = i;
                break;
            }
        }
    }
    public void hacerVisible() {
		setVisible(true);
	}
	public void setControlador(ProgralingoListener controlador) {
		// TODO Auto-generated method stub
		
	}
}

